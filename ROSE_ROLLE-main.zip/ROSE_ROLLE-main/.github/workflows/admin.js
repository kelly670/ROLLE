document.addEventListener('DOMContentLoaded', () => {
  // Hamburger menu for admin
  const hamburger = document.querySelector('.hamburger');
  const navLinks = document.createElement('nav');
  navLinks.className = 'nav-links';
  navLinks.innerHTML = '<a href="index.html">Home</a>';
  
  if (hamburger) {
    hamburger.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      navLinks.classList.toggle('active');
    });

    navLinks.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        navLinks.classList.remove('active');
      });
    });

    // Close menu when clicking outside
    document.addEventListener('click', (e) => {
      if (!hamburger.contains(e.target) && !navLinks.contains(e.target)) {
        navLinks.classList.remove('active');
      }
    });

    hamburger.parentElement.appendChild(navLinks);
  }

  const loginSection = document.getElementById('login-section');
  const dashboardSection = document.getElementById('dashboard-section');
  const loginForm = document.getElementById('login-form');
  const addItemForm = document.getElementById('add-item-form');
  const categorySelect = document.getElementById('category');
  const loginMessage = document.getElementById('login-message');
  let editingItemId = null;

  // Check if logged in
  if (localStorage.getItem('adminLoggedIn') === 'true') {
    showDashboard();
  } else {
    showLogin();
  }

  // Login form submit
  loginForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    fetch('/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    })
    .then(response => response.json())
    .then(data => {
      if (data.success && data.role === 'admin') {
        localStorage.setItem('adminLoggedIn', 'true');
        showDashboard();
      } else {
        loginMessage.textContent = 'Invalid username or password';
      }
    })
    .catch(err => {
      loginMessage.textContent = 'Login failed';
    });
  });

  function showLogin() {
    loginSection.style.display = 'block';
    dashboardSection.style.display = 'none';
  }

  function showDashboard() {
    loginSection.style.display = 'none';
    dashboardSection.style.display = 'block';

    // Logout button
    document.getElementById('logout-btn').addEventListener('click', () => {
      localStorage.removeItem('adminLoggedIn');
      showLogin();
    });

    // Setup page navigation
    const pageNavButtons = document.querySelectorAll('.admin-nav-btn');
    const pages = document.querySelectorAll('.admin-page');

    pageNavButtons.forEach(btn => {
      btn.addEventListener('click', () => {
        // Remove active class from all buttons and pages
        pageNavButtons.forEach(b => b.classList.remove('active'));
        pages.forEach(p => p.classList.remove('active'));

        // Add active class to clicked button and corresponding page
        btn.classList.add('active');
        const pageId = btn.getAttribute('data-page') + '-page';
        document.getElementById(pageId).classList.add('active');
      });
    });

    // Load categories
    fetch('/api/categories')
      .then(response => response.json())
      .then(categories => {
        categories.forEach(cat => {
          const option = document.createElement('option');
          option.value = cat.name;
          option.textContent = cat.name;
          categorySelect.appendChild(option);
        });
      });

    // Handle add/update item form
    addItemForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const formData = new FormData();
      formData.append('name', document.getElementById('name').value);
      formData.append('category', categorySelect.value);
      formData.append('price', document.getElementById('price').value);
      formData.append('description', document.getElementById('description').value);
      const imageInput = document.getElementById('image');
      if (imageInput.files[0]) {
        formData.append('image', imageInput.files[0]);
      }

      if (editingItemId) {
        // update existing item
        fetch(`/api/items/${editingItemId}`, {
          method: 'PUT',
          body: formData
        })
        .then(response => response.json())
        .then(() => {
          alert('Item updated');
          resetAddForm();
          loadItems();
        })
        .catch(() => alert('Failed to update item'));
      } else {
        // create new item
        fetch('/api/items', {
          method: 'POST',
          body: formData
        })
        .then(response => response.json())
        .then(() => {
          alert('Item added');
          addItemForm.reset();
          loadItems();
        });
      }
    });

    function resetAddForm() {
      editingItemId = null;
      addItemForm.reset();
      const submitBtn = addItemForm.querySelector('button[type="submit"]');
      if (submitBtn) submitBtn.textContent = 'Add Item';
    }

    loadItems();
    loadMessages();
  }

  // Load all items
  function loadItems() {
    fetch('/api/items')
      .then(response => response.json())
      .then(items => {
        const container = document.getElementById('all-items');
        container.innerHTML = '';
        items.forEach(item => {
          const div = document.createElement('div');
          div.className = 'item';
          div.innerHTML = `
            <h3>${item.name}</h3>
            <p>${item.description}</p>
            <p>Price: KES ${item.price}</p>
            <img src="${item.image}" alt="${item.name}">
            <div class="item-actions">
              <a href="tel:+254721338398" class="call-btn">Call to Inquire</a>
              <button class="edit-item-btn" data-id="${item.id}">Edit</button>
              <button class="delete-item-btn" data-id="${item.id}">Delete</button>
            </div>
          `;
          container.appendChild(div);

          // attach edit/delete handlers
          const editBtn = div.querySelector('.edit-item-btn');
          const delBtn = div.querySelector('.delete-item-btn');

          if (editBtn) {
            editBtn.addEventListener('click', () => {
              // populate form
              editingItemId = item.id;
              document.getElementById('name').value = item.name || '';
              document.getElementById('price').value = item.price || '';
              document.getElementById('description').value = item.description || '';
              // select category if present
              if (item.category) {
                const opt = Array.from(categorySelect.options).find(o => o.value === item.category);
                if (opt) opt.selected = true;
              }
              // change submit text
              const submitBtn = addItemForm.querySelector('button[type="submit"]');
              if (submitBtn) submitBtn.textContent = 'Update Item';
              // switch to Items page if not visible
              const itemsPage = document.getElementById('items-page');
              const messagesPage = document.getElementById('messages-page');
              if (itemsPage && messagesPage && !itemsPage.classList.contains('active')) {
                document.querySelectorAll('.admin-nav-btn').forEach(b => b.classList.remove('active'));
                document.querySelector('.admin-nav-btn[data-page="items"]').classList.add('active');
                itemsPage.classList.add('active');
                messagesPage.classList.remove('active');
              }
              window.scrollTo({ top: 0, behavior: 'smooth' });
            });
          }

          if (delBtn) {
            delBtn.addEventListener('click', () => {
              if (!confirm('Delete this item?')) return;
              fetch(`/api/items/${item.id}`, { method: 'DELETE' })
                .then(res => res.json())
                .then(resp => {
                  if (resp.success) {
                    loadItems();
                  } else {
                    alert('Failed to delete item');
                  }
                })
                .catch(() => alert('Failed to delete item'));
            });
          }
        });
      });
  }

  // Load all contact messages
  function loadMessages() {
    fetch('/api/contacts')
      .then(response => response.json())
      .then(contacts => {
        const container = document.getElementById('messages-list');
        container.innerHTML = '';
        if (contacts.length === 0) {
          container.innerHTML = '<div class="messages-empty">No messages yet</div>';
          return;
        }
        contacts.forEach(contact => {
          const div = document.createElement('div');
          div.className = 'message-card';
          if (!contact.isRead) div.classList.add('unread');
          const date = new Date(contact.createdAt).toLocaleString();
          div.innerHTML = `
            <div class="message-card-header">
              <div class="message-card-info">
                <p class="message-card-name">${contact.name}</p>
                <p class="message-card-email"><a href="mailto:${contact.email}">${contact.email}</a></p>
              </div>
              <div style="display:flex;align-items:center;gap:0.5rem;">
                <div class="message-card-date">${date}</div>
                <button class="message-read-toggle" data-id="${contact.id}">${contact.isRead ? 'Mark Unread' : 'Mark Read'}</button>
                <button class="message-delete-btn" data-id="${contact.id}" title="Delete message">Delete</button>
              </div>
            </div>
            <div class="message-card-body">${contact.message}</div>
          `;
          container.appendChild(div);

          // attach read toggle handler
          const toggleBtn = div.querySelector('.message-read-toggle');
          if (toggleBtn) {
            toggleBtn.addEventListener('click', () => {
              const id = toggleBtn.getAttribute('data-id');
              const makeRead = toggleBtn.textContent.includes('Mark Read') || toggleBtn.textContent === 'Mark Read';
              const newState = toggleBtn.textContent === 'Mark Read' ? 1 : 0;
              fetch(`/api/contacts/${id}/read`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ isRead: toggleBtn.textContent === 'Mark Read' })
              })
                .then(res => res.json())
                .then(resp => {
                  if (resp.success) loadMessages();
                })
                .catch(() => alert('Failed to update read state'));
            });
          }

          // attach delete handler
          const delBtn = div.querySelector('.message-delete-btn');
          if (delBtn) {
            delBtn.addEventListener('click', () => {
              if (!confirm('Delete this message?')) return;
              fetch(`/api/contacts/${contact.id}`, { method: 'DELETE' })
                .then(res => res.json())
                .then(resp => {
                  if (resp.success) {
                    loadMessages();
                  } else {
                    alert('Failed to delete message');
                  }
                })
                .catch(() => alert('Failed to delete message'));
            });
          }
        });
      })
      .catch(err => {
        console.error('Error loading messages:', err);
        document.getElementById('messages-list').innerHTML = '<div class="messages-empty">Error loading messages</div>';
      });
  }
});