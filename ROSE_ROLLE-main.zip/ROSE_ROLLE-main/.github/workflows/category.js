document.addEventListener('DOMContentLoaded', () => {
  // Hamburger menu
  const hamburger = document.querySelector('.hamburger');
  const navLinks = document.querySelector('.nav-links');
  
  if (hamburger) {
    hamburger.addEventListener('click', () => {
      navLinks.classList.toggle('active');
    });

    // Close menu when a link is clicked
    navLinks.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        navLinks.classList.remove('active');
      });
    });
  }

  const urlParams = new URLSearchParams(window.location.search);
  const cat = urlParams.get('cat');
  document.getElementById('category-title').textContent = cat;

  fetch(`/api/items/${encodeURIComponent(cat)}`)
    .then(response => response.json())
    .then(items => {
      const container = document.getElementById('items');
      items.forEach(item => {
        const div = document.createElement('div');
        div.className = 'item';
        div.innerHTML = `
          <h3>${item.name}</h3>
          <p>${item.description}</p>
          <p>Price: KES ${item.price}</p>
          <img src="${item.image}" alt="${item.name}">
          <a href="tel:+254721338398" class="call-btn">Call to Inquire</a>
        `;
        container.appendChild(div);
      });
    });
});