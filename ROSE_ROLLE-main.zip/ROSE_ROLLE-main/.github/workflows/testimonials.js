document.addEventListener('DOMContentLoaded', () => {
  // Hamburger menu
  const hamburger = document.querySelector('.hamburger');
  const navLinks = document.querySelector('.nav-links');
  
  if (hamburger && navLinks) {
    hamburger.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      navLinks.classList.toggle('active');
    });

    // Close menu when a link is clicked
    navLinks.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        navLinks.classList.remove('active');
      });
    });

    // Close menu when clicking outside
    document.addEventListener('click', (e) => {
      if (!hamburger.contains(e.target) && !navLinks.contains(e.target)) {
        navLinks.classList.remove('active');
      }
    });
  }

  const form = document.getElementById('testimonial-form');
  const testimonialsDiv = document.getElementById('testimonials');

  // Load testimonials
  loadTestimonials();

  // Handle form submit
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const comment = document.getElementById('comment').value;
    const rating = document.getElementById('rating').value;

    fetch('/api/testimonials', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, comment, rating })
    })
    .then(response => {
      if (response.ok) {
        return response.json();
      } else {
        return response.json().then(err => { throw new Error(err.error); });
      }
    })
    .then(() => {
      alert('Thank you for your testimonial!');
      form.reset();
      loadTestimonials();
    })
    .catch(err => {
      alert(err.message);
    });
  });

  function loadTestimonials() {
    fetch('/api/testimonials')
      .then(response => response.json())
      .then(testimonials => {
        testimonialsDiv.innerHTML = '';
        testimonials.forEach(testimonial => {
          const div = document.createElement('div');
          div.className = 'testimonial';
          const stars = '★'.repeat(testimonial.rating) + '☆'.repeat(5 - testimonial.rating);
          div.innerHTML = `
            <h4>${testimonial.name}</h4>
            <p>${testimonial.comment}</p>
            <p class="rating">${stars}</p>
          `;
          testimonialsDiv.appendChild(div);
        });
      });
  }
});