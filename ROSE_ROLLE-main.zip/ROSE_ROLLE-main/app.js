const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');
const multer = require('multer');

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, '../public')));

// Multer config
const storage = multer.diskStorage({
  destination: 'public/uploads/',
  filename: (req, file, cb) => {
    cb(null, Date.now() + '-' + file.originalname);
  }
});
const upload = multer({ storage });

// Database setup
const db = new sqlite3.Database('./database.db');

// Create tables
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    category TEXT,
    price REAL,
    description TEXT,
    image TEXT
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    password TEXT,
    role TEXT DEFAULT 'user'
  )`);

  db.run(`DROP TABLE IF EXISTS testimonials`);
  db.run(`CREATE TABLE IF NOT EXISTS testimonials (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    email TEXT,
    comment TEXT,
    rating INTEGER
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS contacts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    email TEXT,
    message TEXT,
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  // Ensure contacts table has isRead column for read/unread state
  db.all("PRAGMA table_info('contacts')", (err, cols) => {
    if (err) return console.error('PRAGMA error:', err.message);
    const hasIsRead = cols.some(c => c.name === 'isRead');
    if (!hasIsRead) {
      db.run("ALTER TABLE contacts ADD COLUMN isRead INTEGER DEFAULT 0", (err2) => {
        if (err2) console.error('Failed to add isRead column:', err2.message);
      });
    }
  });

  // Remove insecure default credentials
  db.run(`DELETE FROM users WHERE username = 'admin'`);
  
  // Insert secure admin user
  db.run(`INSERT OR IGNORE INTO users (username, password, role) VALUES ('ADMINROSE', 'ROSE@123', 'admin')`);
});

// Routes
app.get('/api/items', (req, res) => {
  db.all('SELECT * FROM items', [], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

app.get('/api/items/:category', (req, res) => {
  const category = req.params.category;
  db.all('SELECT * FROM items WHERE category = ?', [category], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

app.post('/api/items', upload.single('image'), (req, res) => {
  const { name, category, price, description } = req.body;
  const image = req.file ? '/uploads/' + req.file.filename : req.body.image;
  db.run('INSERT INTO items (name, category, price, description, image) VALUES (?, ?, ?, ?, ?)',
    [name, category, price, description, image], function(err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ id: this.lastID });
    });
});

// Update an item (fields and optional image)
app.put('/api/items/:id', upload.single('image'), (req, res) => {
  const id = req.params.id;
  const { name, category, price, description } = req.body;
  const image = req.file ? '/uploads/' + req.file.filename : null;

  if (image) {
    db.run('UPDATE items SET name = ?, category = ?, price = ?, description = ?, image = ? WHERE id = ?',
      [name, category, price, description, image, id], function(err) {
        if (err) return res.status(500).json({ error: err.message });
        if (this.changes === 0) return res.status(404).json({ error: 'Item not found' });
        res.json({ success: true });
      });
  } else {
    db.run('UPDATE items SET name = ?, category = ?, price = ?, description = ? WHERE id = ?',
      [name, category, price, description, id], function(err) {
        if (err) return res.status(500).json({ error: err.message });
        if (this.changes === 0) return res.status(404).json({ error: 'Item not found' });
        res.json({ success: true });
      });
  }
});

// Delete an item
app.delete('/api/items/:id', (req, res) => {
  const id = req.params.id;
  db.run('DELETE FROM items WHERE id = ?', [id], function(err) {
    if (err) return res.status(500).json({ error: err.message });
    if (this.changes === 0) return res.status(404).json({ error: 'Item not found' });
    res.json({ success: true });
  });
});

app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  db.get('SELECT * FROM users WHERE username = ? AND password = ?', [username, password], (err, row) => {
    if (err) return res.status(500).json({ error: err.message });
    if (row) {
      res.json({ success: true, role: row.role });
    } else {
      res.status(401).json({ success: false, message: 'Invalid credentials' });
    }
  });
});

app.get('/api/testimonials', (req, res) => {
  db.all('SELECT * FROM testimonials ORDER BY id DESC', [], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

app.post('/api/testimonials', (req, res) => {
  const { name, email, comment, rating } = req.body;
  db.get('SELECT id FROM testimonials WHERE email = ?', [email], (err, row) => {
    if (err) return res.status(500).json({ error: err.message });
    if (row) {
      return res.status(400).json({ error: 'A testimonial from this email already exists.' });
    }
    db.run('INSERT INTO testimonials (name, email, comment, rating) VALUES (?, ?, ?, ?)',
      [name, email, comment, rating], function(err) {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ id: this.lastID });
      });
  });
});

app.post('/api/contact', (req, res) => {
  const { name, email, message } = req.body;
  if (!name || !email || !message) {
    return res.status(400).json({ error: 'Please fill in all fields.' });
  }
  db.run('INSERT INTO contacts (name, email, message) VALUES (?, ?, ?)',
    [name, email, message], function(err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ id: this.lastID, success: true, message: 'Message received! We will contact you soon.' });
    });
});

app.get('/api/contacts', (req, res) => {
  db.all('SELECT * FROM contacts ORDER BY createdAt DESC', [], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

// Toggle read/unread state for a message
app.put('/api/contacts/:id/read', (req, res) => {
  const id = req.params.id;
  const { isRead } = req.body;
  db.run('UPDATE contacts SET isRead = ? WHERE id = ?', [isRead ? 1 : 0, id], function(err) {
    if (err) return res.status(500).json({ error: err.message });
    if (this.changes === 0) return res.status(404).json({ error: 'Message not found' });
    res.json({ success: true });
  });
});

// Delete a contact message by id
app.delete('/api/contacts/:id', (req, res) => {
  const id = req.params.id;
  db.run('DELETE FROM contacts WHERE id = ?', [id], function(err) {
    if (err) return res.status(500).json({ error: err.message });
    if (this.changes === 0) return res.status(404).json({ error: 'Message not found' });
    res.json({ success: true });
  });
});

app.get('/api/categories', (req, res) => {
  const categories = [
    { name: 'Electronics', image: 'https://tse2.mm.bing.net/th/id/OIP.WN5I08ubB_zQXozGL6ZqCAHaFg?rs=1&pid=ImgDetMain&o=7&rm=3', description: 'Find the latest gadgets and electronic devices.' },
    { name: 'Kitchen ware', image: 'https://www.kent.co.in/images/kitchen-appliances/kitchen-appliances-banner.png', description: 'Essential tools for your kitchen needs.' },
    { name: 'Decors', image: 'https://mydecor.co.ke/?srsltid=AfmBOopP2SWeR5p5585bPnxza1UiRoP5DuJVnX8lqQIcacl0h9OGpJGD', description: 'Beautiful items to decorate your home.' },
    { name: 'Mats and carpets', image: 'https://via.placeholder.com/300x200?text=Mats+and+Carpets', description: 'Comfortable flooring solutions.' },
    { name: 'Kids clothes & shoes', image: 'https://via.placeholder.com/300x200?text=Kids+Clothes', description: 'Clothing and footwear for children.' },
    { name: '2 piece', image: 'https://via.placeholder.com/300x200?text=2+Piece', description: 'Stylish two-piece outfits.' },
    { name: 'Dresses', image: 'https://via.placeholder.com/300x200?text=Dresses', description: 'Elegant dresses for every occasion.' },
    { name: 'Sweaters', image: 'https://via.placeholder.com/300x200?text=Sweaters', description: 'Warm and cozy sweaters.' },
    { name: 'Shoes', image: 'https://via.placeholder.com/300x200?text=Shoes', description: 'Comfortable and stylish footwear.' },
    { name: 'Sandals', image: 'https://via.placeholder.com/300x200?text=Sandals', description: 'Casual sandals for everyday wear.' },
    { name: 'Sneakers', image: 'https://via.placeholder.com/300x200?text=Sneakers', description: 'Sporty sneakers for active lifestyles.' },
    { name: 'Back to school', image: 'https://via.placeholder.com/300x200?text=Back+to+School', description: 'Supplies and items for school.' },
    { name: 'Thrifted dresses', image: 'https://via.placeholder.com/300x200?text=Thrifted+Dresses', description: 'Pre-loved dresses at great prices.' },
    { name: 'New dresses', image: 'https://via.placeholder.com/300x200?text=New+Dresses', description: 'Brand new dresses in fashion.' },
    { name: 'Trenchcoats', image: 'https://via.placeholder.com/300x200?text=Trenchcoats', description: 'Classic trenchcoats for style.' },
    { name: 'Tops', image: 'https://via.placeholder.com/300x200?text=Tops', description: 'Versatile tops for any outfit.' },
    { name: 'Swimming costumes', image: 'https://via.placeholder.com/300x200?text=Swimming+Costumes', description: 'Swimwear for beach and pool.' },
    { name: 'Night wears', image: 'https://via.placeholder.com/300x200?text=Night+Wears', description: 'Comfortable nightwear.' },
    { name: 'Open shoes', image: 'https://via.placeholder.com/300x200?text=Open+Shoes', description: 'Open-toed shoes for summer.' },
    { name: 'Heels', image: 'https://via.placeholder.com/300x200?text=Heels', description: 'Elegant heels for formal occasions.' },
    { name: 'Boots', image: 'https://via.placeholder.com/300x200?text=Boots', description: 'Stylish boots for all seasons.' }
  ];
  res.json(categories);
});

// Admin routes
app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/admin.html'));
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});